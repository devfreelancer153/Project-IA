declare module "svgmap";
